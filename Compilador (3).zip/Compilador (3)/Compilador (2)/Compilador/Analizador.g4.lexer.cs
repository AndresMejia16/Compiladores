﻿namespace Compilador
{
    partial class AnalizadorLexer
    {
    }
}
